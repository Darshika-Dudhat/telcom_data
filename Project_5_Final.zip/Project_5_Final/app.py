import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

# Title and Description
st.title("User Satisfaction Dashboard")
st.write("Analyze engagement and experience metrics interactively.")

# Sidebar for filters
st.sidebar.title("Filters")
engagement_filter = st.sidebar.slider("Engagement Threshold", 0.0, 1.0, 0.5, 0.1)
experience_filter = st.sidebar.slider("Experience Threshold", 0.0, 1.0, 0.5, 0.1)

# Example Data
data = {
    'User': ['A', 'B', 'C', 'D', 'E'],
    'Engagement': [0.1, 0.6, 0.8, 0.3, 0.9],
    'Experience': [0.2, 0.5, 0.9, 0.4, 0.8],
    'Satisfaction': [0.15, 0.55, 0.85, 0.35, 0.85]
}
df = pd.DataFrame(data)

# Apply Filters
filtered_df = df[(df['Engagement'] >= engagement_filter) & (df['Experience'] >= experience_filter)]

# Display the filtered data
st.subheader("Filtered Data")
st.write(filtered_df)

# Satisfaction Analysis
st.subheader("Satisfaction Analysis")
fig, ax = plt.subplots()
ax.scatter(df['Engagement'], df['Experience'], c=df['Satisfaction'], cmap='viridis', s=100)
ax.set_xlabel("Engagement")
ax.set_ylabel("Experience")
ax.set_title("Satisfaction Distribution")
st.pyplot(fig)

# Display statistics
st.subheader("Summary Statistics")
st.write(df.describe())

# Dynamic Line Chart
st.subheader("Engagement and Experience Over Users")
st.line_chart(df[['Engagement', 'Experience']])

# Download Filtered Data
st.subheader("Download Filtered Data")
st.write("Download the filtered data as a CSV file:")
csv = filtered_df.to_csv(index=False)
st.download_button("Download CSV", data=csv, file_name="filtered_data.csv", mime="text/csv")

# To run to the Dashboard
#python -m stremlit run app.py
