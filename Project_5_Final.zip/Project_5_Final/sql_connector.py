import pandas as pd
import mysql.connector
from sqlalchemy import create_engine
from sqlalchemy.sql import text
import logging

# Load the final dataset
file_path = './combined_data.xlsx'
data = pd.read_excel(file_path)

# Normalize column names
data.columns = data.columns.str.strip().str.lower()

# Ensure required columns exist
required_columns = ['msisdn/number', 'engagement_score', 'experience_score', 'satisfaction_score']
if not all(col in data.columns for col in required_columns):
    raise ValueError("Required columns are missing from the dataset.")

# MySQL database credentials
MYSQL_HOST = '127.0.0.1'  # Replace with your MySQL server address
MYSQL_USER = 'root'       # Replace with your MySQL username
MYSQL_PASSWORD = 'computereng'  # Replace with your MySQL password
MYSQL_DATABASE = 'telcom_data_db'  # Replace with your database name

# Establish connection to MySQL
db_url = f'mysql+mysqlconnector://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:3306/{MYSQL_DATABASE}'
engine = create_engine(db_url, pool_pre_ping=True)

# Test database connection
try:
    with engine.connect() as conn:
        conn.execute(text("SELECT 1;"))
    print("Database connection successful.")
except Exception as e:
    print(f"Database connection failed: {e}")

try:
    with engine.connect() as conn:
        conn.rollback()  # Rollback any incomplete transaction
except Exception as e:
    print(f"Error during rollback: {e}")

logging.basicConfig()
logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)

# Export the final table to MySQL
table_name = 'user_satisfaction_data'
try:
    data.to_sql(name=table_name, con=engine, if_exists='replace', index=False, method="multi")
    print(f"Table '{table_name}' successfully exported to MySQL database '{MYSQL_DATABASE}'.")
except Exception as e:
    print(f"Error exporting data to MySQL: {e}")
    engine.dispose()

logging.basicConfig()
logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)

# Query the exported table to verify
try:
    connection = mysql.connector.connect(
        host=MYSQL_HOST,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE
    )
    cursor = connection.cursor()
    cursor.execute(f"SELECT * FROM {table_name} LIMIT 10;")
    results = cursor.fetchall()
    
    print("Sample data from the MySQL table:")
    for row in results:
        print(row)

    cursor.close()
    connection.close()
except Exception as e:
    print(f"Error querying the MySQL database: {e}")
